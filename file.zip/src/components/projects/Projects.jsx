import React from 'react'
import Card from '../card/card'
import e from "../../assets/e.png"
import list from "../../assets/list.png"
import a from "../../assets/a.png"
import w from "../../assets/w.png"
import s from "../../assets/s.png"
import "./Projects.css"


function Projects() {
  return (
   <div id="Projects">
    <h1 id="para"> EXPERIENCED IN PROJECTS</h1>
    <div className="slider">
<Card title="E-Commerce" image={e} />
<Card title="TO-DOLIST" image={list}/>
<Card title="Calculator" image={a}/>  
<Card title="Weather-App" image={w}/>
<Card title="AI CHATBOT" image={s}/>

   </div>
   </div>
  )
}

export default Projects
