// import React from 'react'
// import c from "../../assets/c.png"
// import "./Contact.css"
// function Contact() {
//   return (
//     <div id="Contact">
//         <div className="leftContact">
//             <img src={c} alt="" />
//         </div>
//         <div className="rightContact">
//             <form action="https://formspree.io/f/xwpqjkgj" method='POST'>
//                 <input name="username" type="text" 
//                 placeholder='Name'/>
//                 <input  name="Email" type="email" placeholder='Email'/>
//                 <textarea name="Message" id="textarea" placeholder='Message Me'></textarea>
//                 <input type="submit" id="btn" value="Submit"/>
//             </form>
//         </div>
      
//     </div>
//   )
// }

// export default Contact
// import React from 'react'
// import c from "../../assets/c.png"
// import { FaGithub, FaLinkedin } from "react-icons/fa"; 
// import "./Contact.css"

// function Contact() {
//   return (
//     <div id="Contact">
//       <div className="leftContact">
//          <div style={{ fontSize: '60px', color: 'red' }}>
//       <FaGithub />
//     </div>
//         <img src={c} alt="" />
        
        
//         <div className="social-icons">
//           <a href="https://github.com/YourGitHubUsername" target="_blank" rel="noopener noreferrer">
//             <FaGithub className="icon github" />
//           </a>
//           <a href="https://linkedin.com/in/YourLinkedInUsername" target="_blank" rel="noopener noreferrer">
//             <FaLinkedin className="icon linkedin" />
//           </a>
//         </div>
//       </div>

//       <div className="rightContact">
//         <form action="https://formspree.io/f/xwpqjkgj" method='POST'>
//           <input name="username" type="text" placeholder='Name'/>
//           <input name="Email" type="email" placeholder='Email'/>
//           <textarea name="Message" id="textarea" placeholder='Message Me'></textarea>
//           <input type="submit" id="btn" value="Submit"/>
//         </form>
//       </div>
//     </div>
//   )
// }

// export default Contact

import React from 'react';
import c from "../../assets/c.png";
import { FaGithub, FaLinkedin } from "react-icons/fa";
import "./Contact.css";

function Contact() {
  return (
    <div id="Contact">
      <div className="leftContact">
        <img src={c} alt="Contact illustration" />

        <div className="social-icons">
          <a href="https://github.com/YourGitHubUsername" target="_blank" rel="noopener noreferrer">
            <FaGithub className="icon github" />
          </a>
          <a href="https://linkedin.com/in/YourLinkedInUsername" target="_blank" rel="noopener noreferrer">
            <FaLinkedin className="icon linkedin" />
          </a>
        </div>
      </div>

      <div className="rightContact">
        <form action="https://formspree.io/f/xwpqjkgj" method="POST">
          <input name="username" type="text" placeholder="Name" />
          <input name="Email" type="email" placeholder="Email" />
          <textarea name="Message" id="textarea" placeholder="Message Me"></textarea>
          <input type="submit" id="btn" value="Submit" />
        </form>
      </div>
    </div>
  );
}

export default Contact;
