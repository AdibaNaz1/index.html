import React from 'react'
import "./About.css"
import Card from '../card/card'
import DSA from "../../assets/DSA.png";
import java from "../../assets/java.png"
import mern from "../../assets/mern.png"
 

function About() {
  return (
    <div id="About">
<div className="leftabout">
  <div className="circle-line">
    <div className="circle"></div>
    <div className="line"></div>
    <div className="circle"></div>
    <div className="line"></div>
    <div className="circle"></div>
  </div>
  <div className="aboutdetails">
    <div className="personalinfo">   
      <h1>Personal Info</h1>
      <ul>
         <li>
<span>NAME</span> : ADIBA NAZ
        </li>  
        <li>
<span>AGE</span> : 23 YEARS
        </li>
         <li>  
<span>GENDER</span> : FEMALE
        </li>
         <li>
<span>LANGUAGE KNOWN</span> : ENGLISH, HINDI
        </li>
      </ul>
    </div>
     <div className="education">
      <h1>EDUCATION</h1>
      <ul>
         <li>
<span>DEGREE</span> : B-TECH
        </li>
        <li>
<span>BRANCH</span> :  COMPUTER SCIENCE & ENGINEERING
        </li>
         <li>
<span>CGPA</span> : 8.2
        </li>
        <div className="skills">
          
      <h1>skills</h1>
           
      <ul>
         <li>
MERN STACK WEB DEVELOPER
        </li>
        <li>
DSA
        </li>
         <li>
JAVA
        </li>
         
      </ul>
     
    </div>
    </ul>
    </div>
  </div>
</div>
  <div className="rightabout">
<Card title="MERN STACK WEB DEVELOPER"image={mern}/>
<Card title="JAVA" image={java}className="java"/>
<Card title="DSA"image={DSA}/>

</div>

    </div>
  )
}

export default About

