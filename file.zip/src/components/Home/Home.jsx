// import React from 'react'
// import "./Home.css";
// import man from "../../assets/man.jpg"
// import ReactTypingEffect from "react-typing-effect";

// function Home() {
//   return (
//     <div id="Home">
// <div className="lefthome">
//  <div className="homedetails">
//       <div className="line1">I 'M</div>
//       <div className="line2">ADIBA NAZ</div>
//       <div className="line3">
//         <TypingEffect
//         text={["WEB DEVELOPER", "SOFTWARE DEVELOPER", "EDITOR"]}
//         speed={100}
//         eraseSpeed={50}
//         eraseDelay={500}
//         typingDelay={500}
//         cursor='|'
//         />
       
//       </div>
  
//   </div> 

// </div>
// <div className="rigthhome"> 
//   <img src={man} alt="" />

// </div>
 
      
//     </div>
//   );
// }

// export default Home;

import React from 'react';
import "./Home.css";
import man from "../../assets/man.jpg";
import { Typewriter } from 'react-simple-typewriter';
import { Button } from 'react-scroll';

function Home() {
  return (
    <div id="Home">
      <div className="lefthome">
        <div className="homedetails">
          <div className="line1">I 'M</div>
          <div className="line2">ADIBA NAZ</div>
          <div className="line3">
            <span>
              <Typewriter
                words={['MERN STACK DEVELOPER,', 'JAVA ENTHUSIAST', 'UI/UX DESIGNER']}
                loop={true}
                cursor
                cursorStyle='|'
                typeSpeed={100}
                deleteSpeed={30}
                delaySpeed={800}
               />        
            </span>
          </div>
          <Button>HIRE ME</Button>
        </div>
      </div>

      <div className="rigthhome">
        <img src={man} alt="" />
      </div>
    </div>
  );
}

export default Home;
