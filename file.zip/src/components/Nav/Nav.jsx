// import React from 'react'
// import "./Nav.css"
// import {Link} from "react-scroll"
// function Nav() {
//   return (
//     <nav>
//         <h1>PORTFOLIO</h1>
//         { <ul className='desktopmenu'></ul> }
//         <ul>
//             <Link to="Home" activeClass='active' spy={true} smooth={true} duration={500}><li>Home</li></Link>
//             <Link to ="About" activeClass='active' spy={true} smooth={true} duration={500}><li>About</li></Link>
//             <Link to="Projects"activeClass='active' spy={true} smooth={true} duration={500}><li>Projects</li></Link>
//             <Link to="Contact" activeClass='active' spy={true} smooth={true} duration={500}><li>Contact</li></Link> 
//         </ul>
//          <div className="hamburger" ref={menu}>
//             <div className="ham"></div>
//             <div className="ham"></div>
//             <div className="ham"></div>
//         </div>
//         { <ul className='mobilemenu '></ul> }
//         { <ul>
//             <Link to="Home" activeClass='active' spy={true} smooth={true} duration={500}><li>Home</li></Link>
//             <Link to ="About" activeClass='active' spy={true} smooth={true} duration={500}><li>About</li></Link>
//             <Link to="Projects"activeClass='active' spy={true} smooth={true} duration={500}><li>Projects</li></Link>
//             <Link to="Contact" activeClass='active' spy={true} smooth={true} duration={500}><li>Contact</li></Link> 
//         </ul>   }
//     </nav>
    
//   )
// }

// export default Nav

// import React, { useRef, useState } from "react";
// import "./Nav.css";
// import { Link } from "react-scroll";

// function Nav() {
//   const menuRef = useRef();
//   const [isOpen, setIsOpen] = useState(false);

//   const toggleMenu = () => {
//     setIsOpen(!isOpen);
//     menuRef.current.classList.toggle("show");
//   };

//   return (
//     <nav>
//       <h1>PORTFOLIO</h1>

     
//       <ul className="desktopmenu">
//         <Link to="Home" activeClass="active" spy={true} smooth={true} duration={500}><li>Home</li></Link>
//         <Link to="About" activeClass="active" spy={true} smooth={true} duration={500}><li>About</li></Link>
//         <Link to="Projects" activeClass="active" spy={true} smooth={true} duration={500}><li>Projects</li></Link>
//         <Link to="Contact" activeClass="active" spy={true} smooth={true} duration={500}><li>Contact</li></Link>
//       </ul>

     
//       <div className="hamburger" onClick={toggleMenu}>
//         <div className="ham"></div>
//         <div className="ham"></div>
//         <div className="ham"></div>
//       </div>

     
//       <ul className="mobilemenu" ref={menuRef}>
//         <Link to="Home" activeClass="active" spy={true} smooth={true} duration={500}><li>Home</li></Link>
//         <Link to="About" activeClass="active" spy={true} smooth={true} duration={500}><li>About</li></Link>
//         <Link to="Projects" activeClass="active" spy={true} smooth={true} duration={500}><li>Projects</li></Link>
//         <Link to="Contact" activeClass="active" spy={true} smooth={true} duration={500}><li>Contact</li></Link>
//       </ul>
//     </nav>
//   );
// }

// export default Nav;


// import React, { useRef, useState } from "react";
// import "./Nav.css";
// import { Link } from "react-scroll";

// function Nav() {
//   const menuRef = useRef();
//   const [isOpen, setIsOpen] = useState(false);

//   const toggleMenu = () => {
//     setIsOpen(!isOpen);
//   };

//   const closeMenu = () => {
//     setIsOpen(false);
//   };

//   const menuItems = ["Home", "About", "Projects", "Contact"];

//   return (
//     <nav>
//       <h1>PORTFOLIO</h1>

     
//       <ul className="desktopmenu">
//         {menuItems.map((item) => (
//           <Link
//             key={item}
//             to={item}
//             activeClass="active"
//             spy={true}
//             smooth={true}
//             duration={500}
//           >
//             <li>{item}</li>
//           </Link>
//         ))}
//       </ul>

//       <div className="hamburger" onClick={toggleMenu}>
//         <div className="ham"></div>
//         <div className="ham"></div>
//         <div className="ham"></div>
//       </div>

      
//       <ul
//         ref={menuRef}
//         className={`mobilemenu ${isOpen ? "show" : ""}`}
//         onClick={closeMenu}
//       >
//         {menuItems.map((item) => (
//           <Link
//             key={item}
//             to={item}
//             activeClass="active"
//             spy={true}
//             smooth={true}
//             duration={500}
//           >
//             <li>{item}</li>
//           </Link>
//         ))}
//       </ul>
//     </nav>
//   );
// }

// export default Nav;

// import React, { useState } from "react";
// import "./Nav.css";
// import { Link } from "react-scroll";

// function Nav() {
//   const [isOpen, setIsOpen] = useState(false);

//   const toggleMenu = () => {
//     setIsOpen(!isOpen);
//   };

//   const closeMenu = () => {
//     setIsOpen(false);
//   };

//   const menuItems = ["Home", "About", "Projects", "Contact"];

//   return (
//     <nav>
//       <h1>PORTFOLIO</h1>

//       <ul className="desktopmenu">
//         {menuItems.map((item) => (
//           <Link
//             key={item}
//             to={item}
//             activeClass="active"
//             spy={true}
//             smooth={true}
//             duration={500}
//           >
//             <li>{item}</li>
//           </Link>
//         ))}
//       </ul>

//       {/* Hamburger with conditional "open" class */}
//       <div
//         className={`hamburger ${isOpen ? "open" : ""}`}
//         onClick={toggleMenu}
//       >
//         <div className="ham"></div>
//         <div className="ham"></div>
//         <div className="ham"></div>
//       </div>

//       <div className={`mobilemenu-wrapper ${isOpen ? "show" : ""}`}>
//         <ul className="mobilemenu" onClick={closeMenu}>
//           {menuItems.map((item) => (
//             <Link
//               key={item}
//               to={item}
//               activeClass="active"
//               spy={true}
//               smooth={true}
//               duration={500}
//             >
//               <li>{item}</li>
//             </Link>
//           ))}
//         </ul>
//       </div>
//     </nav>
//   );
// }

// export default Nav;

// import React, { useState } from "react";
// import "./Nav.css";
// import { Link } from "react-scroll";

// function Nav() {
//   const [isOpen, setIsOpen] = useState(false);

//   const toggleMenu = () => {
//     setIsOpen(!isOpen);
//   };

//   const closeMenu = () => {
//     setIsOpen(false);
//   };

//   const menuItems = ["Home", "About", "Projects", "Contact"];

//   return (
//     <nav>
//       <h1>PORTFOLIO</h1>

//       {/* Desktop Menu */}
//       <ul className="desktopmenu">
//         {menuItems.map((item) => (
//           <Link
//             key={item}
//             to={item}
//             activeClass="active"
//             spy={true}
//             smooth={true}
//             duration={500}
//           >
//             <li>{item}</li>
//           </Link>
//         ))}
//       </ul>

//       {/* Hamburger */}
//       <div className="hamburger" onClick={toggleMenu}>
//         <div className="ham"></div>
//         <div className="ham"></div>
//         <div className="ham"></div>
//       </div>

      
//       <div className={`mobilemenu-wrapper ${isOpen ? "show" : ""}`}>
//         <ul className="mobilemenu" onClick={closeMenu}>
//           {menuItems.map((item) => (
//             <Link
//               key={item}
//               to={item}
//               activeClass="active"
//               spy={true}
//               smooth={true}
//               duration={500}
//             >
//               <li>{item}</li>
//             </Link>
//           ))}
//         </ul>
//       </div>
//     </nav>
//   );
// }

// export default Nav;
import React, { useState } from "react";
import "./Nav.css";
import { Link } from "react-scroll";

function Nav() {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const closeMenu = () => {
    setIsOpen(false);
  };

  const menuItems = ["Home", "About", "Projects", "Contact"];

  return (
    <nav>
      <h1>PORTFOLIO</h1>

     
      <ul className="desktopmenu">
        {menuItems.map((item) => (
          <Link
            key={item}
            to={item}
            activeClass="active"
            spy={true}
            smooth={true}
            duration={500}
          >
            <li>{item}</li>
          </Link>
        ))}
      </ul>

      {/* Hamburger */}
      <div
        className={`hamburger ${isOpen ? "open" : ""}`}
        onClick={toggleMenu}
        aria-label="Toggle menu"
      >
        <div className="ham"></div>
        <div className="ham"></div>
        <div className="ham"></div>
      </div>

      {/* Mobile Slide-In Menu */}
      <div className={`mobilemenu-wrapper ${isOpen ? "show" : ""}`}>
        <ul className="mobilemenu" onClick={closeMenu}>
          {menuItems.map((item) => (
            <Link
              key={item}
              to={item}
              activeClass="active"
              spy={true}
              smooth={true}
              duration={500}
            >
              <li>{item}</li>
            </Link>
          ))}
        </ul>
      </div>
    </nav>
  );
}

export default Nav;

// import React, { useState, useEffect } from "react";
// import "./Nav.css";
// import { Link } from "react-scroll";
// import AOS from "aos";
// import "aos/dist/aos.css";

// function Nav() {
//   const [isOpen, setIsOpen] = useState(false);

//   useEffect(() => {
//     AOS.init({ duration: 1000, once: true });
//   }, []);

//   const toggleMenu = () => {
//     setIsOpen(!isOpen);
//   };

//   const closeMenu = () => {
//     setIsOpen(false);
//   };

//   const menuItems = ["Home", "About", "Projects", "Contact"];

//   return (
//     <>
//       <nav>
//         <h1>PORTFOLIO</h1>

//         {/* Desktop Menu */}
//         <ul className="desktopmenu">
//           {menuItems.map((item) => (
//             <Link
//               key={item}
//               to={item}
//               activeClass="active"
//               spy={true}
//               smooth={true}
//               duration={500}
//             >
//               <li>{item}</li>
//             </Link>
//           ))}
//         </ul>

//         {/* Hamburger */}
//         <div
//           className={`hamburger ${isOpen ? "open" : ""}`}
//           onClick={toggleMenu}
//           aria-label="Toggle menu"
//         >
//           <div className="ham"></div>
//           <div className="ham"></div>
//           <div className="ham"></div>
//         </div>

//         {/* Mobile Slide-In Menu */}
//         <div className={`mobilemenu-wrapper ${isOpen ? "show" : ""}`}>
//           <ul className="mobilemenu" onClick={closeMenu}>
//             {menuItems.map((item) => (
//               <Link
//                 key={item}
//                 to={item}
//                 activeClass="active"
//                 spy={true}
//                 smooth={true}
//                 duration={500}
//               >
//                 <li>{item}</li>
//               </Link>
//             ))}
//           </ul>
//         </div>
//       </nav>

//       {/* All sections below in same file for testing */}
//       <section id="Home" style={{ height: "100vh", background: "#222" }}>
//         <h2 style={{ color: "white", paddingTop: "100px", textAlign: "center" }}>
//           Home Section
//         </h2>
//       </section>

//       <section
//         id="About"
//         data-aos="slide-up"
//         style={{
//           height: "100vh",
//           background: "#111",
//           color: "white",
//           textAlign: "center",
//           paddingTop: "100px",
//         }}
//       >
//         <h2>About Me</h2>
//         <p style={{ maxWidth: "600px", margin: "auto", marginTop: "20px" }}>
//           I'm a developer passionate about building awesome web experiences.
//         </p>
//       </section>

//       <section id="Projects" style={{ height: "100vh", background: "#333" }}>
//         <h2 style={{ color: "white", paddingTop: "100px", textAlign: "center" }}>
//           Projects Section
//         </h2>
//       </section>

//       <section id="Contact" style={{ height: "100vh", background: "#555" }}>
//         <h2 style={{ color: "white", paddingTop: "100px", textAlign: "center" }}>
//           Contact Section
//         </h2>
//       </section>
//     </>
//   );
// }

// export default Nav;
