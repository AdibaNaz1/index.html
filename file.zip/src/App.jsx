import About from "./components/about/about"
import Contact from "./components/contact/contact"
import Home from "./components/home/home"
import Nav from "./components/Nav/Nav"
import Projects from "./components/projects/projects"


function App() {
  
  return (
    <>
      <Nav/>
      <Home/>
      <About/>
      <Projects/>
      <Contact/>

      
      

   </>
  )
}

export default App

